import torch
from typing import Tuple, Optional, Dict
from functools import partial

# Lazy import: CuTe kernel only available on Hopper (sm90+)
_CUTE_AVAILABLE = None


def _check_cute_available():
    global _CUTE_AVAILABLE
    if _CUTE_AVAILABLE is not None:
        return _CUTE_AVAILABLE
    try:
        from flash_attn.cute.interface import _flash_attn_fwd, _flash_attn_bwd
        from flash_attn.cute.compute_block_sparsity import compute_block_sparsity
        cap = torch.cuda.get_device_capability()
        if cap[0] >= 9:  # sm90+ (Hopper)
            _CUTE_AVAILABLE = True
        else:
            _CUTE_AVAILABLE = False
    except (ImportError, ModuleNotFoundError):
        _CUTE_AVAILABLE = False
    return _CUTE_AVAILABLE


SUMMARY_ATTN_CACHE: Dict[Tuple, Tuple] = {}


# ---------------------------------------------------------------------------
# CuTe kernel path (Hopper only)
# ---------------------------------------------------------------------------

class SummaryAttnFunc(torch.autograd.Function):
    @staticmethod
    def _get_cached_value(
        seqlen_q, seqlen_k, chunk_size, summary_num, sliding_chunk_num,
        skip_old_summary=False, is_fwd=True, m_block_size=128, n_block_size=128,
    ):
        from flash_attn.cute.compute_block_sparsity import compute_block_sparsity
        from .mask import (
            summary_attn_mask_func, summary_attn_contiguous_mask_func,
            sliding_chunk_mask_func, sliding_chunk_contiguous_mask_func,
        )

        prefix_summary_length = seqlen_k - seqlen_q
        cache_key = (seqlen_q, chunk_size, summary_num, sliding_chunk_num,
                     prefix_summary_length, skip_old_summary, is_fwd)
        if cache_key not in SUMMARY_ATTN_CACHE:
            if skip_old_summary:
                func = sliding_chunk_contiguous_mask_func if prefix_summary_length > 0 else sliding_chunk_mask_func
            else:
                func = summary_attn_contiguous_mask_func if prefix_summary_length > 0 else summary_attn_mask_func
            mask_mod = partial(func, chunk_size=chunk_size, summary_num=summary_num,
                               sliding_chunk_num=sliding_chunk_num,
                               prefix_summary_length=prefix_summary_length, swap_indices=False)
            mask_swap_mod = mask_mod
            if not is_fwd:
                mask_swap_mod = partial(func, chunk_size=chunk_size, summary_num=summary_num,
                                        sliding_chunk_num=sliding_chunk_num,
                                        prefix_summary_length=prefix_summary_length, swap_indices=True)
                m_block_size, n_block_size = n_block_size, m_block_size
                seqlen_q, seqlen_k = seqlen_k, seqlen_q
            _, block_sparse = compute_block_sparsity(
                m_block_size, n_block_size, 1, 1, seqlen_q, seqlen_k,
                mask_swap_mod, None, "cuda",
            )
            SUMMARY_ATTN_CACHE[cache_key] = (block_sparse, mask_mod)
        return SUMMARY_ATTN_CACHE[cache_key]

    @staticmethod
    def forward(ctx, q, k, v, chunk_size, summary_num, sliding_chunk_num,
                softmax_scale=None, causal=False, pack_gqa=None,
                deterministic=False, skip_old_summary=False):
        from flash_attn.cute.interface import _flash_attn_fwd
        block_sparse, mask_mod = SummaryAttnFunc._get_cached_value(
            q.shape[1], k.shape[1], chunk_size, summary_num, sliding_chunk_num,
            skip_old_summary=skip_old_summary, is_fwd=True, m_block_size=128, n_block_size=64,
        )
        out, lse = _flash_attn_fwd(q, k, v, softmax_scale=softmax_scale, causal=causal,
                                     pack_gqa=pack_gqa, mask_mod=mask_mod,
                                     block_sparse_tensors=block_sparse,
                                     m_block_size=128, n_block_size=64)
        ctx.save_for_backward(q, k, v, out, lse)
        ctx.softmax_scale = softmax_scale
        ctx.causal = causal
        ctx.deterministic = deterministic
        ctx.chunk_size = chunk_size
        ctx.summary_num = summary_num
        ctx.sliding_chunk_num = sliding_chunk_num
        ctx.skip_old_summary = skip_old_summary
        return out, lse

    @staticmethod
    def backward(ctx, dout, *args):
        from flash_attn.cute.interface import _flash_attn_bwd
        q, k, v, out, lse = ctx.saved_tensors
        block_sparse, mask_mod = SummaryAttnFunc._get_cached_value(
            q.shape[1], k.shape[1], ctx.chunk_size, ctx.summary_num, ctx.sliding_chunk_num,
            skip_old_summary=ctx.skip_old_summary, is_fwd=False, m_block_size=128, n_block_size=128,
        )
        dq, dk, dv = _flash_attn_bwd(q, k, v, out, dout, lse,
                                       softmax_scale=ctx.softmax_scale, causal=ctx.causal,
                                       deterministic=ctx.deterministic, mask_mod=mask_mod,
                                       block_sparse_tensors=block_sparse,
                                       m_block_size=64, n_block_size=128)
        return dq, dk, dv, *((None,) * 20)


# ---------------------------------------------------------------------------
# FlexAttention path (Ampere / any GPU with PyTorch >= 2.5)
# ---------------------------------------------------------------------------

_FLEX_BLOCK_MASK_CACHE: Dict[Tuple, object] = {}


def _create_block_mask_no_materialize(mask_mod, seq_len_q, seq_len_k, device, BLOCK_SIZE=128):
    """Create BlockMask without materializing the full (seq_len_q, seq_len_k) dense mask.

    Processes one q_block row at a time, reducing peak memory from
    O(seq_q * seq_k) to O(BLOCK_SIZE * seq_k).
    """
    from torch.nn.attention.flex_attention import BlockMask

    num_q_blocks = (seq_len_q + BLOCK_SIZE - 1) // BLOCK_SIZE
    num_kv_blocks = (seq_len_k + BLOCK_SIZE - 1) // BLOCK_SIZE

    # Block-level sparsity: (num_q_blocks, num_kv_blocks)
    any_mask = torch.zeros(num_q_blocks, num_kv_blocks, dtype=torch.bool, device=device)
    full_mask = torch.zeros(num_q_blocks, num_kv_blocks, dtype=torch.bool, device=device)

    kv_arange = torch.arange(seq_len_k, device=device)
    pad_k = (-seq_len_k) % BLOCK_SIZE
    last_kv_len = seq_len_k - (num_kv_blocks - 1) * BLOCK_SIZE if seq_len_k % BLOCK_SIZE else BLOCK_SIZE

    for q_blk in range(num_q_blocks):
        q_start = q_blk * BLOCK_SIZE
        q_end = min(q_start + BLOCK_SIZE, seq_len_q)
        q_len = q_end - q_start
        q_idx = torch.arange(q_start, q_end, device=device)

        # (q_len, seq_len_k) bool
        mask = mask_mod(0, 0, q_idx[:, None], kv_arange[None, :])

        if pad_k > 0:
            mask = torch.nn.functional.pad(mask, (0, pad_k), value=False)

        # (q_len, num_kv_blocks, BLOCK_SIZE) -> sum per block
        block_sums = mask.reshape(q_len, num_kv_blocks, BLOCK_SIZE).sum(dim=(0, 2))

        any_mask[q_blk] = block_sums > 0
        full_mask[q_blk] = block_sums == (q_len * BLOCK_SIZE)
        # Last kv block may be shorter
        if pad_k > 0:
            full_mask[q_blk, -1] = block_sums[-1] == (q_len * last_kv_len)

    def _bool_mask_to_compact(mask_2d):
        """Convert (rows, cols) bool mask to (num_per_row, indices) format."""
        num_per_row = mask_2d.sum(dim=1).to(torch.int32)
        max_num = max(num_per_row.max().item(), 1)
        sorted_idx = mask_2d.to(torch.int32).argsort(dim=1, descending=True, stable=True)
        indices = sorted_idx[:, :max_num].to(torch.int32)
        return num_per_row, indices

    kv_num_blocks, kv_indices = _bool_mask_to_compact(any_mask)
    full_kv_num_blocks, full_kv_indices = _bool_mask_to_compact(full_mask)
    q_num_blocks, q_indices = _bool_mask_to_compact(any_mask.t().contiguous())
    full_q_num_blocks, full_q_indices = _bool_mask_to_compact(full_mask.t().contiguous())

    return BlockMask(
        kv_num_blocks=kv_num_blocks[None, None],
        kv_indices=kv_indices[None, None],
        full_kv_num_blocks=full_kv_num_blocks[None, None],
        full_kv_indices=full_kv_indices[None, None],
        q_num_blocks=q_num_blocks[None, None],
        q_indices=q_indices[None, None],
        full_q_num_blocks=full_q_num_blocks[None, None],
        full_q_indices=full_q_indices[None, None],
        BLOCK_SIZE=(BLOCK_SIZE, BLOCK_SIZE),
        mask_mod=mask_mod,
        seq_lengths=(seq_len_q, seq_len_k),
    )


def _get_flex_block_mask(seq_len_q, seq_len_k, chunk_size, summary_num, sliding_chunk_num,
                          skip_old_summary, device):
    cache_key = (seq_len_q, seq_len_k, chunk_size, summary_num, sliding_chunk_num, skip_old_summary)
    if cache_key not in _FLEX_BLOCK_MASK_CACHE:
        block = chunk_size + summary_num
        prefix_summary_length = seq_len_k - seq_len_q

        if prefix_summary_length > 0:
            def mask_mod(b, h, q_idx, kv_idx):
                q_chunk_id = q_idx // block
                kv_chunk_id = (kv_idx - prefix_summary_length) // block
                is_sliding = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
                is_q_summary = (q_idx % block) >= chunk_size
                is_kv_summary = ((kv_idx - prefix_summary_length) % block) >= chunk_size
                is_causal = q_idx >= (kv_idx - prefix_summary_length)
                valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
                valid_sliding_q_text = is_sliding & (~is_kv_summary) & (kv_idx >= prefix_summary_length)
                if skip_old_summary:
                    valid_kv_q_text = (~is_q_summary) & is_causal & valid_sliding_q_text
                else:
                    valid_summary_q_text = ((kv_idx // summary_num) + sliding_chunk_num) < q_chunk_id
                    valid_kv_q_text = (~is_q_summary) & ((is_causal & valid_sliding_q_text) | valid_summary_q_text)
                return valid_kv_q_summary | valid_kv_q_text
        else:
            def mask_mod(b, h, q_idx, kv_idx):
                q_chunk_id = q_idx // block
                kv_chunk_id = kv_idx // block
                is_sliding = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
                is_q_summary = (q_idx % block) >= chunk_size
                is_kv_summary = (kv_idx % block) >= chunk_size
                is_causal = q_idx >= kv_idx
                valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
                valid_sliding_q_text = is_sliding & (~is_kv_summary)
                if skip_old_summary:
                    valid_kv_q_text = (~is_q_summary) & is_causal & valid_sliding_q_text
                else:
                    valid_summary_q_text = is_kv_summary & ((q_chunk_id - kv_chunk_id) > sliding_chunk_num)
                    valid_kv_q_text = (~is_q_summary) & is_causal & (valid_sliding_q_text | valid_summary_q_text)
                return valid_kv_q_summary | valid_kv_q_text

        block_mask = _create_block_mask_no_materialize(
            mask_mod, seq_len_q, seq_len_k, device,
        )
        _FLEX_BLOCK_MASK_CACHE[cache_key] = block_mask
    return _FLEX_BLOCK_MASK_CACHE[cache_key]


_compiled_flex_attention = None


def _get_compiled_flex_attention():
    global _compiled_flex_attention
    if _compiled_flex_attention is None:
        from torch.nn.attention.flex_attention import flex_attention
        _compiled_flex_attention = torch.compile(flex_attention)
    return _compiled_flex_attention


def _summary_attn_flex(q, k, v, chunk_size, summary_num, sliding_chunk_num, skip_old_summary):
    """FlexAttention-based implementation. Auto-compiles to efficient Triton block-sparse kernel.

    Works on any GPU with PyTorch >= 2.5 (Ampere, Hopper, etc).
    No KV duplication, no Python loops — single fused kernel call.
    """
    b, seq_len_q, h_q, d = q.shape
    _, seq_len_k, h_kv, _ = k.shape
    enable_gqa = (h_q != h_kv)

    block_mask = _get_flex_block_mask(seq_len_q, seq_len_k, chunk_size, summary_num,
                                       sliding_chunk_num, skip_old_summary, q.device)

    # flex_attention expects [B, H, S, D]
    q_flex = q.transpose(1, 2)  # [B, H, S, D]
    k_flex = k.transpose(1, 2)
    v_flex = v.transpose(1, 2)

    compiled_fn = _get_compiled_flex_attention()
    out = compiled_fn(q_flex, k_flex, v_flex, block_mask=block_mask, enable_gqa=enable_gqa)
    out = out.transpose(1, 2)  # [B, S, H, D]

    return out, None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def summary_attn_func(
    q, k, v, chunk_size, summary_num, sliding_chunk_num,
    summary_pos: Optional[torch.Tensor] = None,
    skip_old_summary: bool = False,
):
    if summary_pos is not None:
        k = torch.cat((k[:, summary_pos, :], k), dim=1)
        v = torch.cat((v[:, summary_pos, :], v), dim=1)

    if _check_cute_available():
        out = SummaryAttnFunc.apply(
            q, k, v, chunk_size, summary_num, sliding_chunk_num,
            None, False, None, False, skip_old_summary,
        )
    else:
        out = _summary_attn_flex(
            q, k, v, chunk_size, summary_num, sliding_chunk_num, skip_old_summary,
        )
    return out
