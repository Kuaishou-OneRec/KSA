import cutlass
from cutlass import cute
from flash_attn.cute.seqlen_info import SeqlenInfoQK

@cute.jit
def summary_attn_mask_func(
    batch_idx_ssa: cute.TensorSSA,
    head_idx_ssa: cute.TensorSSA,
    q_idx_ssa: cute.TensorSSA,
    kv_idx_ssa: cute.TensorSSA,
    seqlen_info: SeqlenInfoQK,
    aux_tensors,
    chunk_size: cutlass.Constexpr[int],
    summary_num: cutlass.Constexpr[int],
    sliding_chunk_num: cutlass.Constexpr[int],
    prefix_summary_length: cutlass.Constexpr[int],
    swap_indices: cutlass.Constexpr[bool],
):
    if swap_indices:
        q_idx_ssa, kv_idx_ssa = kv_idx_ssa, q_idx_ssa
    q_chunk_id = q_idx_ssa // (chunk_size + summary_num)
    kv_chunk_id = kv_idx_ssa // (chunk_size + summary_num)
    is_sliding_chunk = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
    is_q_summary = (q_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_kv_summary = (kv_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_causal = q_idx_ssa >= kv_idx_ssa
    valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
    valid_sliding_q_text = is_sliding_chunk & (is_kv_summary ^ 1)
    valid_summary_q_text = is_kv_summary & ((q_chunk_id - kv_chunk_id) > sliding_chunk_num)
    valid_kv_q_text = (is_q_summary ^ 1) & is_causal & (valid_sliding_q_text | valid_summary_q_text)
    return valid_kv_q_summary | valid_kv_q_text

@cute.jit
def summary_attn_contiguous_mask_func(
    batch_idx_ssa: cute.TensorSSA,
    head_idx_ssa: cute.TensorSSA,
    q_idx_ssa: cute.TensorSSA,
    kv_idx_ssa: cute.TensorSSA,
    seqlen_info: SeqlenInfoQK,
    aux_tensors,
    chunk_size: cutlass.Constexpr[int],
    summary_num: cutlass.Constexpr[int],
    sliding_chunk_num: cutlass.Constexpr[int],
    prefix_summary_length: cutlass.Constexpr[int],
    swap_indices: cutlass.Constexpr[bool],
):
    if swap_indices:
        q_idx_ssa, kv_idx_ssa = kv_idx_ssa, q_idx_ssa
    q_chunk_id = q_idx_ssa // (chunk_size + summary_num)
    kv_chunk_id = (kv_idx_ssa - prefix_summary_length) // (chunk_size + summary_num)
    is_sliding_chunk = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
    is_q_summary = (q_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_kv_summary = ((kv_idx_ssa - prefix_summary_length) % (chunk_size + summary_num)) >= chunk_size
    is_causal = q_idx_ssa >= (kv_idx_ssa - prefix_summary_length)
    valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
    valid_sliding_q_text = is_sliding_chunk & (is_kv_summary ^ 1) & (kv_idx_ssa >= prefix_summary_length)
    valid_summary_q_text = ((kv_idx_ssa // summary_num) + sliding_chunk_num) < q_chunk_id
    valid_kv_q_text = (is_q_summary ^ 1) & ((is_causal & valid_sliding_q_text) | valid_summary_q_text)
    return valid_kv_q_summary | valid_kv_q_text

# ---------------------------------------------------------------------------
# Sliding-chunk-only variants: text tokens never attend to old summary tokens
# ---------------------------------------------------------------------------

@cute.jit
def sliding_chunk_mask_func(
    batch_idx_ssa: cute.TensorSSA,
    head_idx_ssa: cute.TensorSSA,
    q_idx_ssa: cute.TensorSSA,
    kv_idx_ssa: cute.TensorSSA,
    seqlen_info: SeqlenInfoQK,
    aux_tensors,
    chunk_size: cutlass.Constexpr[int],
    summary_num: cutlass.Constexpr[int],
    sliding_chunk_num: cutlass.Constexpr[int],
    prefix_summary_length: cutlass.Constexpr[int],
    swap_indices: cutlass.Constexpr[bool],
):
    if swap_indices:
        q_idx_ssa, kv_idx_ssa = kv_idx_ssa, q_idx_ssa
    q_chunk_id = q_idx_ssa // (chunk_size + summary_num)
    kv_chunk_id = kv_idx_ssa // (chunk_size + summary_num)
    is_sliding_chunk = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
    is_q_summary = (q_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_kv_summary = (kv_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_causal = q_idx_ssa >= kv_idx_ssa
    valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
    valid_sliding_q_text = is_sliding_chunk & (is_kv_summary ^ 1)
    valid_kv_q_text = (is_q_summary ^ 1) & is_causal & valid_sliding_q_text
    return valid_kv_q_summary | valid_kv_q_text

@cute.jit
def sliding_chunk_contiguous_mask_func(
    batch_idx_ssa: cute.TensorSSA,
    head_idx_ssa: cute.TensorSSA,
    q_idx_ssa: cute.TensorSSA,
    kv_idx_ssa: cute.TensorSSA,
    seqlen_info: SeqlenInfoQK,
    aux_tensors,
    chunk_size: cutlass.Constexpr[int],
    summary_num: cutlass.Constexpr[int],
    sliding_chunk_num: cutlass.Constexpr[int],
    prefix_summary_length: cutlass.Constexpr[int],
    swap_indices: cutlass.Constexpr[bool],
):
    if swap_indices:
        q_idx_ssa, kv_idx_ssa = kv_idx_ssa, q_idx_ssa
    q_chunk_id = q_idx_ssa // (chunk_size + summary_num)
    kv_chunk_id = (kv_idx_ssa - prefix_summary_length) // (chunk_size + summary_num)
    is_sliding_chunk = (q_chunk_id - kv_chunk_id) <= sliding_chunk_num
    is_q_summary = (q_idx_ssa % (chunk_size + summary_num)) >= chunk_size
    is_kv_summary = ((kv_idx_ssa - prefix_summary_length) % (chunk_size + summary_num)) >= chunk_size
    is_causal = q_idx_ssa >= (kv_idx_ssa - prefix_summary_length)
    valid_kv_q_summary = is_q_summary & (kv_chunk_id == q_chunk_id) & is_causal
    valid_sliding_q_text = is_sliding_chunk & (is_kv_summary ^ 1) & (kv_idx_ssa >= prefix_summary_length)
    valid_kv_q_text = (is_q_summary ^ 1) & is_causal & valid_sliding_q_text
    return valid_kv_q_summary | valid_kv_q_text
